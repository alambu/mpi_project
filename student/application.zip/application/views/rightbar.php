<style>
h2.s2 a:hover{color:white;}
</style>
<div class="card">
		<div class="head-title-bar">
			<div class="secs section-title">
				<h2 class="s2"><i class="fa fa-user" aria-hidden="true"></i> <a href="main/onlineapply">Online Apply</a></h2>
			</div>
		</div>
		
		<div class="head-title-bar">
			<div class="secs section-title">
				<h2 class="s2"><i class="fa fa-book" aria-hidden="true"></i> <a href="academic/admission_info">Admission Information</a></h2>
			</div>
		</div>
		<div class="head-title-bar">
			<div class="secs section-title">
				<h2 class="s2"><i class="fa fa-book" aria-hidden="true"></i> <a href="academic/prospectas">Prospectas</a></h2>
			</div>
		</div>
		<div class="head-title-bar">
			<div class="secs section-title">
				<h2 class="s2"><i class="fa fa-book" aria-hidden="true"></i> <a href="student/blood_bank">Blood Bank</a></h2>
			</div>
		</div>
		
		
		<div class="head-title-bar" style="background:white;">
		<h4 class="s2"><i class="fa fa-user" aria-hidden="true"></i> Online Visitor</h4>
				<div align='center'><a href='http://www.websitecounterfree.com'><img src='http://www.websitecounterfree.com/c.php?d=9&id=12532&s=27' border='0' title='website counter free - free website hitcounter for your website'></a><br / ><small>&nbsp;</small></div>
				
		</div>	
</div>
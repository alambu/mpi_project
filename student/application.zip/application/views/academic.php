<h1 class="title-widget s-h1">Academic</h1>
		<ul>
			<li><a href="academic/admission_info">Admission Information</a></li>
			<li><a href="academic/teachers_staffs">Teacher Information</a></li>
			<li><a href="academic/teachers_staffs">Stuff Information</a></li>
			<li><a href="student/blood_bank">Blood Search</a></li>
			<li><a href="main/gallery">Photo Gallery</a></li>
		</ul>
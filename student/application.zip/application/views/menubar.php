<div class="main-menu-section-area">
        <div class="container-fluid">
            <div class="row">
        	<div class="col-lg-16">
            	<nav id="k-menu" class="k-main-navig"><!-- main navig -->
        
                    <ul id="drop-down-left" class="k-dropdown-menu">
                        <li>
                            <a href="main" title="">Home</a>
                        </li>
                        <li>
                            <a href="main/about" title="">About</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)" title="">Departments</a>
                                <ul class="sub-menu">
                                    <li><a href="department/get_department/automobile">Automobile Engineering</a></li>
                                    <li><a href="department/get_department/architacture">Architecture Engineering</a></li>
                                    <li><a href="department/get_department/computer">Computer Engineering</a></li>
                                    
                                    <li><a href="department/get_department/electrical">Electrical Engineering</a></li>
                                    <li><a href="department/get_department/civil">Civil Engineering</a></li>
                                    <li><a href="department/get_department/marine">Marine Engineering</a></li>
                                    <li><a href="department/get_department/textitle">Textile Engineering</a></li>
                                    
                                </ul>
                        </li>
                        <li>
                                <a href="javascript:void();" title="">Teacher &amp; Stuff</a>
                               <ul class="sub-menu">
                                    <li><a href="academic/teachers_staffs">All Teachers & Stuff </a></li>
                                    <li><a href="department/dept_teachers/Automobile">Automobile Engineering</a></li>
                                    <li><a href="department/dept_teachers/Architacture">Architecture Engineering</a></li>
                                    <li><a href="department/dept_teachers/Computer">Computer Engineering</a></li>   
                                    <li><a href="department/dept_teachers/Electrical">Electrical Engineering</a></li>
                                    <li><a href="department/dept_teachers/Civil">Civil Engineering</a></li>
                                    <li><a href="department/dept_teachers/Marine">Marine Engineering</a></li>
                                    <li><a href="department/dept_teachers/Textitle">Textile Engineering</a></li>
                                    <li><a href="department/dept_teachers/Relative Subject">Relative Subject</a></li>     
                                </ul>
                        </li>
                        
                        <li>
                            <a href="javascript:void(0)" title="">ACADEMIC</a>
                                <ul class="sub-menu">
								 
                                    <li><a href="academic/academic_content/sylabus/1">Syllabus</a></li>
									
                                    <li><a href="academic/academic_content/class_Routine/2">Class Routine</a></li>
                                    <li><a href="academic/academic_content/academic_Calendar/3">Academic Calendar</a></li>		
                                </ul>
                        </li>
						 <li>
                            <a href="javascript:void(0)" title="">Admission</a>		
							<ul class="sub-menu">
                                    <li><a href="academic/academic_content/admission_info/5">Admission Information</a></li>							
                                    <li><a href="academic/academic_content/admission_req/6">Admission Requirement</a></li>
                                    <li><a href="academic/academic_content/admission_form/7">Admission form</a></li>		
                                    <li><a href="academic/online_admission_form">Online Apply</a></li>		
                            </ul>
		               </li>
                        <li>
                            <a href="main/gallery" title="">Gallery</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)" title="">Results</a>
                                <ul class="sub-menu">
                                    <li><a href="mpi">Institute Result</a></li>
                                    <li><a href="academic/board_result">Board Result</a></li>
                                </ul>
                        </li>
                        <li>
                            <a href="javascript:void(0)" title="">Notice</a>
                                <ul class="sub-menu">
                                    <li><a href="main/notice/1">Institute Notice</a></li>
                                    <li><a href="main/notice/2">Board Notice</a></li>
                                </ul>
                        </li>
                       <li>
                            <a href="department/extra_act" title="">Extra Activities</a>
                        </li>
                        <li>
                            <a href="contact" title="">Contact Us</a>
                        </li> 
						<li>
                            <a href="mpi" title="">Login</a>
                        </li>
                    </ul>
        
            	</nav><!-- main navig end -->
            
            </div>
            </div>
        </div>
    </div>
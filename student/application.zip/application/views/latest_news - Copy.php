<div class="row">
						<div class="col-md-12"><!-- Welcome Massage Start-->
							<div class="panel panel-primary">
								<div class="panel-heading" style="font-weight: bold; font-size: 15px;">Latest News</div>
								<div class="panel-body">
								<center><h2><u><?php echo $row->title?></u></h2> </center><br/>
									<p style="text-align: justify; line-height: 1.6;font-family:SolaimanLipi;"><?php echo $row->content?><b><br></b>   
									</p>
								</div>
							</div>
						</div><!-- Welcome M
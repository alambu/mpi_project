  
    <div id="k-footer"><!-- footer -->
        <div id="fb-root"></div>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6&appId=942454595869732";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
    
    	<div class="container"><!-- container -->
        
        	<div class="row no-gutter"><!-- row -->
            
            	<div class="col-lg-4 col-md-4"><!-- widgets column left -->
            
                    <div class="col-padded col-naked">
                    
                        <ul class="list-unstyled clear-margins"><!-- widgets -->
                        
                        	<li class="widget-container widget_nav_menu"><!-- widgets list -->
                    
                                <h1 class="title-widget">Useful links</h1>
                                
                                <ul>
                                	<li><a href="http://www.techedu.gov.bd/" title="">Directorate Of Technichal Education</a></li>
                                    <li><a href="http://www.bteb.gov.bd/" title="">Bangladesh Technical Education Board (BTEB)</a></li>
                                    <li><a href="http://www.moedu.gov.bd/" title="">Ministry of Education</a></li>
                                    <li><a href="http://www.step-dte.gov.bd/" title="">Skills and Training Enhancement Project</a></li>
                                    <li><a href="http://www.bpsc.gov.bd/" title="">Bangladesh Public Service Commission (BPSC)</a></li>
                                    <li><a href="http://www.bcc.gov.bd/" title="">Bangladesh Computer Council (BCC)</a></li>
                                </ul>
                    
							</li>
                            
                        </ul>
                         
                    </div>
                    
                </div><!-- widgets column left end -->
                
                <div class="col-lg-4 col-md-4"><!-- widgets column center -->
                
                    <div class="col-padded col-naked">
                    
                        <ul class="list-unstyled clear-margins"><!-- widgets -->
                        
                        	<li class="widget-container widget_recent_news"><!-- widgets list -->
                    
                                <h1 class="title-widget">Collage Contact</h1>
                                
                                <div> 
                                
                                	<h2 class="title-median m-contact-subject" itemprop="name">MPI</h2>
                                
                                	<div class="m-contact-address">
                                		<span class="m-contact-street" itemprop="street-address">Mirpur -1,Dhaka, Bangladesh</span>
                                	</div>
                                     
                                	<div class="m-contact-tel-fax">
                                    	<span class="m-contact-tel">Tel: <span itemprop="tel"> 0088-0331-62266</span></span>
                                    	<span class="m-contact-fax">Mobile: <span>+8801934-884606, +8801711-949390</span></span>
                                    	<span class="m-contact-fax">Email: <span> mpi69016@gmail.com</span></span>
                                    </div>
                                    
                                </div>
                                
                                <div class="social-icons">
                                
                                	<ul class="list-unstyled list-inline">
                                    
                                    	<li><a href="mailto:MPI69016@gmail.com" title="Contact us"><i class="fa fa-envelope"></i></a></li>
                                        <li><a href="https://www.facebook.com/l.php?u=https%3A%2F%2Ftwitter.com%2FFeniIcst&h=mAQFJvrDY&s=1" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="https://www.facebook.com/Icstfeni/?ref=bookmarks&__mref=message_bubble" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                    
                                    </ul>
                                
                                </div>
                    
							</li>
                            
                        </ul>
                        
                    </div>
                    
                </div><!-- widgets column center end -->
                
                <div class="col-lg-4 col-md-4"><!-- widgets column right -->
                
                    <div class="col-padded col-naked">
                    
                        <ul class="list-unstyled clear-margins"><!-- widgets -->
                        
                        	<li class="widget-container widget_sofa_flickr"><!-- widgets list -->
                    
                                <h1 class="title-widget">MPI Like Page</h1>
<div class="fb-page" 
  data-href="https://www.facebook.com/mpi.com.bd"
  data-width="380" 
  data-hide-cover="false"
  data-show-facepile="true" 
  data-show-posts="false"></div>
                                
                    
							</li>
                            
                        </ul> 
                        
                    </div>
                
                </div><!-- widgets column right end -->
            
            </div><!-- row end -->
        
        </div><!-- container end -->
    
    </div><!-- footer end -->
    
    <div id="k-subfooter"><!-- subfooter -->
    	<div class="container"><!-- container -->
        	<div class="row"><!-- row -->
            	<div class="col-lg-12">
                	<p class="copy-text text-inverse pull-left">
                        Copyright &copy; 2012-<?php echo date('Y');?>  Mirpur Polytechnic Institute(MPI). All rights reserved.
                    </p>
                    
                
                </div>
            
            </div><!-- row end -->
        
        </div><!-- container end -->
    
    </div><!-- subfooter end -->

    <!-- jQuery -->
    <script src="assets/jQuery/jquery-2.1.1.min.js"></script>
    <script src="assets/jQuery/jquery-migrate-1.2.1.min.js"></script>
    
    <!-- Bootstrap -->
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/bootstrap/js/jquery.dataTables.min.js"></script>
    <script src="assets/bootstrap/js/dataTables.bootstrap.min.js"></script>
    
    <!-- Drop-down -->
    <script src="assets/js/dropdown-menu/dropdown-menu.js"></script>
    
    <!-- Fancybox -->
	<script src="assets/js/fancybox/jquery.fancybox.pack.js"></script>
    <script src="assets/js/fancybox/jquery.fancybox-media.js"></script><!-- Fancybox media -->
    
    <!-- Responsive videos -->
    <script src="assets/js/jquery.fitvids.js"></script>
    
    <!-- Audio player -->
	<script src="assets/js/audioplayer/audioplayer.min.js"></script>
    
    <!-- Pie charts -->
    <script src="assets/js/jquery.easy-pie-chart.js"></script>
    <script src="assets/js/jquery.newsTicker.js"></script>
    
    <!-- Theme -->
    <script src="assets/js/theme.js"></script>
    <script src="assets/js/icst.js"></script>
    
  </body>
</html>
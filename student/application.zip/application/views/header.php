<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<base href="<?php echo base_url();?>"/>
    <title>Welcome to Mirpur Polytechnic Institute</title>
	<link rel="shortcut icon" href="../assets/images/mpilogo.png">
    <!-- Styles -->
    <link href="../assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"><!-- font-awesome -->
    <link href="../assets/js/dropdown-menu/dropdown-menu.css" rel="stylesheet" type="text/css"><!-- dropdown-menu -->
    <link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"><!-- Bootstrap -->
    <link href="../assets/bootstrap/css/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css"><!-- Bootstrap -->
    <link href="../assets/js/fancybox/jquery.fancybox.css" rel="stylesheet" type="text/css"><!-- Fancybox -->
    <link href="../assets/js/audioplayer/audioplayer.css" rel="stylesheet" type="text/css"><!-- Audioplayer -->
    <link href="../assets/style.css" rel="stylesheet" type="text/css"><!-- theme styles -->
  </head>
  
  <body role="document">
   
   

    <?php //$this->load->view('menubar');?>
    </div>
<div id="k-body"><!-- content wrapper -->
    
    	<div class="container"><!-- container -->
        
        	<div class="row"><!-- row -->
            
                <div id="k-top-search" class="col-lg-12 clearfix"><!-- top search -->
                
                    <form action="#" id="top-searchform" method="get" role="search">
                        <div class="input-group">
                            <input type="text" name="s" id="sitesearch" class="form-control" autocomplete="off" placeholder="Type in keyword(s) then hit Enter on keyboard" />
                        </div>
                    </form>
                    
                    <div id="bt-toggle-search" class="search-icon text-center"><i class="s-open fa fa-search"></i><i class="s-close fa fa-times"></i></div><!-- toggle search button -->
                
                </div><!-- top search end -->           
                
            </div><!-- row end -->
            
            <div class="row no-gutter"><!-- row -->
                
                <div class="col-lg-12 col-md-12"><!-- doc body wrapper -->
                	
                    <div class="content-panel-box col-padded"><!-- inner custom column -->
                    
                    	<div class="row gutter"><!-- row -->
                        
                        	<div class="col-lg-12 col-md-12">
                               <h1 class="page-title">Civil &amp; Architecture</h1>
                               
                               <div class="row">
                                   <div class="key-person-section-contents">
                                        <div class="col-xs-12 col-sm-6 col-md-6">
                                            <div class="sensitive-box">
                                                <div class="sensitive-image">
                                                <img src="assets/img/teacher01.jpg."weidth="240" height="300" class="img-responsive" alt="">
                                                </div>
                                                    <div class="sensitive-info text-center">
                                                        <h3>Md. Siddique Ur Rahman Khan</h3>
                                                        
                                                        <p><strong>Mobile: </strong> +01718-638806</p>
                                                        <p><strong>Email: </strong><a href="mailto:luminaakhter.888@gmail.com">mpi50455@yahoo.com </a></p>
														<strong>Desgination :</strong> <span>Principal </span>
														<strong>   Department :</strong> <span>Academic </span>
                                                        <p><strong>Qualification: </strong> Bachelor of arts.</p>
                                                        
                           
                                                    </div>

                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6 col-md-6">
                                            <div class="sensitive-box">
                                                <div class="sensitive-image">
                                                <img src="assets/images/teacher02.jpg" class="img-responsive" alt="">
                                                </div>
                                                    <div class="sensitive-info text-center">
                                                        <h3>Mis. Lumina Akter</h3>
                                                        <span>Jr. Instructor(Civil &amp; Architecture)</span>
                                                        <p><strong>Mobile: </strong> +88-01711061</p>
                                                        <p><strong>Email: </strong><a href="mailto:luminaakhter.888@gmail.com">luminaakhter.888@gmail.com </a></p>
                                                        <p><strong>Qualification: </strong> Diploma in Civil Engineering.</p>
                                                        
                                                    </div>

                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6 col-md-6">
                                            <div class="sensitive-box">
                                                <div class="sensitive-image">
                                                <img src="assets/images/teacher03.jpg" class="img-responsive" alt="">
                                                </div>
                                                    <div class="sensitive-info text-center">
                                                        <h3>Mis. Lumina Akter</h3>
                                                        <span>Jr. Instructor(Civil &amp; Architecture)</span>
                                                        <p><strong>Mobile: </strong> +88-01711061</p>
                                                        <p><strong>Email: </strong><a href="mailto:luminaakhter.888@gmail.com">luminaakhter.888@gmail.com </a></p>
                                                        <p><strong>Qualification: </strong> Diploma in Civil Engineering.</p>
                                                        
                                                    </div>

                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6 col-md-6">
                                            <div class="sensitive-box">
                                                <div class="sensitive-image">
                                                <img src="assets/images/teacher04.jpg" class="img-responsive" alt="">
                                                </div>
                                                    <div class="sensitive-info text-center">
                                                        <h3>Mis. Lumina Akter</h3>
                                                        <span>Jr. Instructor(Civil &amp; Architecture)</span>
                                                        <p><strong>Mobile: </strong> +88-01711061</p>
                                                        <p><strong>Email: </strong><a href="mailto:luminaakhter.888@gmail.com">luminaakhter.888@gmail.com </a></p>
                                                        <p><strong>Qualification: </strong> Diploma in Civil Engineering.</p>
                                                        
                                                    </div>

                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6 col-md-6">
                                            <div class="sensitive-box">
                                                <div class="sensitive-image">
                                                <img src="assets/images/teacher05.jpg" class="img-responsive" alt="">
                                                </div>
                                                    <div class="sensitive-info text-center">
                                                        <h3>Mis. Lumina Akter</h3>
                                                        <span>Jr. Instructor(Civil &amp; Architecture)</span>
                                                        <p><strong>Mobile: </strong> +88-01711061</p>
                                                        <p><strong>Email: </strong><a href="mailto:luminaakhter.888@gmail.com">luminaakhter.888@gmail.com </a></p>
                                                        <p><strong>Qualification: </strong> Diploma in Civil Engineering.</p>
                                                        
                                                    </div>

                                            </div>
                                        </div>
                                        <div class="col-xs-12 col-sm-6 col-md-6">
                                            <div class="sensitive-box">
                                                <div class="sensitive-image">
                                                <img src="assets/images/teacher06.jpg" class="img-responsive" alt="">
                                                </div>
                                                    <div class="sensitive-info text-center">
                                                        <h3>Mis. Lumina Akter</h3>
                                                        <span>Jr. Instructor(Civil &amp; Architecture)</span>
                                                        <p><strong>Mobile: </strong> +88-01711061</p>
                                                        <p><strong>Email: </strong><a href="mailto:luminaakhter.888@gmail.com">luminaakhter.888@gmail.com </a></p>
                                                        <p><strong>Qualification: </strong> Diploma in Civil Engineering.</p>
                                                        
                                                    </div>

                                            </div>
                                        </div>
                                       
                                   </div>
                                   
                               </div>
                                    <div class="row gutter"><!-- row -->

                                        <div class="col-lg-12">

                                            <ul class="pagination pull-right"><!-- pagination -->
                                                <li class="disabled"><a href="#">Prev</a></li>
                                                <li class="active"><a href="#">1</a></li>
                                                <li><a href="#">2</a></li>
                                                <li><a href="#">3</a></li>
                                                <li><a href="#">4</a></li>
                                                <li><a href="#">5</a></li>
                                                <li><a href="#">Next</a></li>
                                            </ul><!-- pagination end -->

                                        </div>

                                    </div>
                            
                            </div>
                        
                        </div><!-- row end -->          
                    
                    </div><!-- inner custom column end -->
                    
                </div><!-- doc body wrapper end -->
            
            </div><!-- row end -->
        
        </div><!-- container end -->
    
    </div><!-- content wrapper end -->